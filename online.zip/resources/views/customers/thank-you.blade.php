@extends('layouts.request-form')
@section('content')
<div class="main">
    <div class="container" style="padding-top: 1%">
        <h2>UK-Dion Online Investment Form</h2>
        <h5>Thank You for Filling out the application form, a representative will call you shortly</h5>
    </div>
</div>
@endsection